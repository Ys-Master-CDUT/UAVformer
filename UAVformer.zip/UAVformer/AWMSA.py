# coding:utf-8

import torch
import torch.nn as nn
from torch.nn import init
from torch import nn, einsum
import numpy as np
from einops import rearrange, repeat
import torch.nn.functional as F
import torchvision
from torch.optim import lr_scheduler
import torch.nn.functional as F
from torch.hub import load_state_dict_from_url
from typing import Type, Any, Callable, Union, List, Optional
from torchvision.models.resnet import ResNet, Bottleneck
import math



class CyclicShift(nn.Module):
    def __init__(self, displacement):
        super().__init__()
        self.displacement = displacement

    def forward(self, x):
        return torch.roll(x, shifts=(self.displacement, self.displacement), dims=(1, 2))




class Residual(nn.Module):
    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def forward(self, x, **kwargs):
        return self.fn(x, **kwargs) + x

class PreNorm(nn.Module):
    def __init__(self, dim, fn):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.fn = fn

    def forward(self, x, **kwargs):
        return self.fn(self.norm(x), **kwargs)


class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, dim),
        )

    def forward(self, x):
        return self.net(x)


def create_mask(window_size, displacement, upper_lower, left_right):
    mask = torch.zeros(window_size ** 2, window_size ** 2)

    if upper_lower:
        mask[-displacement * window_size:, :-displacement * window_size] = float('-inf')
        mask[:-displacement * window_size, -displacement * window_size:] = float('-inf')

    if left_right:
        mask = rearrange(mask, '(h1 w1) (h2 w2) -> h1 w1 h2 w2', h1=window_size, h2=window_size)
        mask[:, -displacement:, :, :-displacement] = float('-inf')
        mask[:, :-displacement, :, -displacement:] = float('-inf')
        mask = rearrange(mask, 'h1 w1 h2 w2 -> (h1 w1) (h2 w2)')

    return mask


def get_relative_distances(window_size):
    indices = torch.tensor(np.array([[x, y] for x in range(window_size) for y in range(window_size)]))
    distances = indices[None, :, :] - indices[:, None, :]
    return distances



class WindowAttention(nn.Module):
    def __init__(self, dim, heads, head_dim, shifted, window_size, relative_pos_embedding):
        super().__init__()
        inner_dim = head_dim * heads

        self.heads = heads
        self.scale = head_dim ** -0.5
        self.window_size = window_size
        self.relative_pos_embedding = relative_pos_embedding
        self.shifted = shifted
        

        
        if self.shifted:
            displacement1 = window_size//2 #! 分为3个支路 每个支路得窗口大小成一定比例关系
            self.cyclic_shift1 = CyclicShift(displacement1)
            self.cyclic_back_shift1 = CyclicShift(-displacement1)
            self.upper_lower_mask1 = nn.Parameter(create_mask(window_size=window_size, displacement=displacement1,
                                                             upper_lower=True, left_right=False), requires_grad=False)
            self.left_right_mask1 = nn.Parameter(create_mask(window_size=window_size, displacement=displacement1,
                                                            upper_lower=False, left_right=True), requires_grad=False)
            displacement2 = window_size//8
            self.cyclic_shift2 = CyclicShift(displacement2)
            self.cyclic_back_shift2 = CyclicShift(-displacement2)
            self.upper_lower_mask2 = nn.Parameter(create_mask(window_size=window_size//4, displacement=displacement2,
                                                             upper_lower=True, left_right=False), requires_grad=False)
            self.left_right_mask2 = nn.Parameter(create_mask(window_size=window_size//4, displacement=displacement2,
                                                            upper_lower=False, left_right=True), requires_grad=False)

            displacement3 = window_size//16
            self.cyclic_shift3 = CyclicShift(displacement3)
            self.cyclic_back_shift3 = CyclicShift(-displacement3)
            self.upper_lower_mask3 = nn.Parameter(create_mask(window_size=window_size//8, displacement=displacement3,
                                                             upper_lower=True, left_right=False), requires_grad=False)
            self.left_right_mask3 = nn.Parameter(create_mask(window_size=window_size//8, displacement=displacement3,
                                                            upper_lower=False, left_right=True), requires_grad=False)            

        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias=False)
        
        if self.relative_pos_embedding:
            self.relative_indices1 = get_relative_distances(window_size) + window_size - 1
            self.pos_embedding1 = nn.Parameter(torch.randn(2 * window_size - 1, 2 * window_size - 1))

            self.relative_indices2 = get_relative_distances(window_size//4) + window_size//4 - 1
            self.pos_embedding2 = nn.Parameter(torch.randn(2 * window_size//4 - 1, 2 * window_size//4 - 1))

            self.relative_indices3 = get_relative_distances(window_size//8) + window_size//8 - 1
            self.pos_embedding3 = nn.Parameter(torch.randn(2 * window_size//8 - 1, 2 * window_size//8 - 1))            
        else:
            self.pos_embedding1 = nn.Parameter(torch.randn(window_size ** 2, window_size ** 2))
            self.pos_embedding2 = nn.Parameter(torch.randn(window_size//4 ** 2, window_size//4 ** 2))
            self.pos_embedding3 = nn.Parameter(torch.randn(window_size//8 ** 2, window_size//8 ** 2))            
        self.to_out = nn.Linear(inner_dim, dim)

    def forward(self, x):

        x1=x
        x2=x
        x3=x

        
        if self.shifted:
            x1 = self.cyclic_shift1(x)
            x2 = self.cyclic_shift2(x)
            x3 = self.cyclic_shift3(x)
        
        b1, n_h1, n_w1, _, h1 = *x1.shape, self.heads
        b2, n_h2, n_w2, _, h2 = *x2.shape, self.heads
        b3, n_h3, n_w3, _, h3 = *x3.shape, self.heads

        qkv1 = self.to_qkv(x1).chunk(3, dim=-1)
        nw_h1 = n_h1 // self.window_size
        nw_w1 = n_w1 // self.window_size
        qkv2 = self.to_qkv(x2).chunk(3, dim=-1)
        nw_h2 = n_h2 // (self.window_size//4)
        nw_w2 = n_w2 // (self.window_size//4)
        qkv3 = self.to_qkv(x3).chunk(3, dim=-1)
        nw_h3 = n_h3 // (self.window_size//8)
        nw_w3 = n_w3 // (self.window_size//8)        

        q1, k1, v1 = map(
            lambda t: rearrange(t, 'b1 (nw_h1 w_h1) (nw_w1 w_w1) (h1 d) -> b1 h1 (nw_h1 nw_w1) (w_h1 w_w1) d',
                                h1=h1, w_h1=self.window_size, w_w1=self.window_size), qkv1)
        q2, k2, v2 = map(
            lambda t: rearrange(t, 'b2 (nw_h2 w_h2) (nw_w2 w_w2) (h2 d) -> b2 h2 (nw_h2 nw_w2) (w_h2 w_w2) d',
                                h2=h2, w_h2=self.window_size//4, w_w2=self.window_size//4), qkv2)
        q3, k3, v3 = map(
            lambda t: rearrange(t, 'b3 (nw_h3 w_h3) (nw_w3 w_w3) (h3 d) -> b3 h3 (nw_h3 nw_w3) (w_h3 w_w3) d',
                                h3=h3, w_h3=self.window_size//8, w_w3=self.window_size//8), qkv3)         
                                                                                        
        

        dots1 = einsum('b h w i d, b h w j d -> b h w i j', q1, k1) * self.scale
        dots2 = einsum('b h w i d, b h w j d -> b h w i j', q2, k2) * self.scale       
        dots3 = einsum('b h w i d, b h w j d -> b h w i j', q3, k3) * self.scale

        if self.relative_pos_embedding:
            dots1 += self.pos_embedding1[self.relative_indices1[:, :, 0], self.relative_indices1[:, :, 1]]
            dots2 += self.pos_embedding2[self.relative_indices2[:, :, 0], self.relative_indices2[:, :, 1]]
            dots3 += self.pos_embedding3[self.relative_indices3[:, :, 0], self.relative_indices3[:, :, 1]]            
        else:
            dots1 += self.pos_embedding1
            dots2 += self.pos_embedding2
            dots3 += self.pos_embedding3            

        if self.shifted:
            dots1[:, :, -nw_w1:] += (self.upper_lower_mask1) #! 将3条支路的mask相加
            dots1[:, :, nw_w1 - 1::nw_w1] += (self.left_right_mask1)
            dots2[:, :, -nw_w2:] += (self.upper_lower_mask2) 
            dots2[:, :, nw_w2 - 1::nw_w2] += (self.left_right_mask2)
            dots3[:, :, -nw_w3:] += (self.upper_lower_mask3) 
            dots3[:, :, nw_w3 - 1::nw_w3] += (self.left_right_mask3)            

        attn1 = dots1.softmax(dim=-1)
        attn2 = dots2.softmax(dim=-1)
        attn3 = dots3.softmax(dim=-1)        

        out1 = einsum('b h w i j, b h w j d -> b h w i d', attn1, v1)
        out1 = rearrange(out1, 'b1 h1 (nw_h1 nw_w1) (w_h1 w_w1) d -> b1 (nw_h1 w_h1) (nw_w1 w_w1) (h1 d)',
                        h1=h1, w_h1=self.window_size, w_w1=self.window_size, nw_h1=nw_h1, nw_w1=nw_w1)
        out1 = self.to_out(out1)
        
        out2 = einsum('b h w i j, b h w j d -> b h w i d', attn2, v2)
        out2 = rearrange(out2, 'b2 h2 (nw_h2 nw_w2) (w_h2 w_w2) d -> b2 (nw_h2 w_h2) (nw_w2 w_w2) (h2 d)',
                        h2=h2, w_h2=self.window_size//4, w_w2=self.window_size//4, nw_h2=nw_h2, nw_w2=nw_w2)
        out2 = self.to_out(out2)

        out3 = einsum('b h w i j, b h w j d -> b h w i d', attn3, v3)
        out3 = rearrange(out3, 'b3 h3 (nw_h3 nw_w3) (w_h3 w_w3) d -> b3 (nw_h3 w_h3) (nw_w3 w_w3) (h3 d)',
                        h3=h3, w_h3=self.window_size//8, w_w3=self.window_size//8, nw_h3=nw_h3, nw_w3=nw_w3)
        out3 = self.to_out(out3)         

        out = out1 + out2 + out3
        
        if self.shifted:

            out1 = self.cyclic_back_shift1(out1)
            out2 = self.cyclic_back_shift2(out2)
            out3 = self.cyclic_back_shift3(out3)

            out = out1 + out2 + out3
        
        return out             





class SwinBlock(nn.Module):
    def __init__(self, dim, heads, head_dim, mlp_dim, shifted, window_size, relative_pos_embedding):
        super().__init__()
        self.attention_block = Residual(PreNorm(dim, WindowAttention(dim=dim,
                                                                     heads=heads,
                                                                     head_dim=head_dim,
                                                                     shifted=shifted,
                                                                     window_size=window_size,
                                                                     relative_pos_embedding=relative_pos_embedding)))
        self.mlp_block = Residual(PreNorm(dim, FeedForward(dim=dim, hidden_dim=mlp_dim)))


    def forward(self, x):
        x = self.attention_block(x)
        x = self.mlp_block(x)

        return x


class PatchMerging(nn.Module):
    def __init__(self, in_channels, out_channels, downscaling_factor):
        super().__init__()
        self.downscaling_factor = downscaling_factor
        self.patch_merge = nn.Conv2d(in_channels, out_channels, kernel_size=downscaling_factor, stride=downscaling_factor, padding=0)
        #self.linear = nn.Linear(in_channels * downscaling_factor ** 2, out_channels)
        self.bn = nn.BatchNorm2d(out_channels)
    def forward(self, x):
        b, c, h, w = x.shape

        new_h, new_w = h // self.downscaling_factor, w // self.downscaling_factor
        # x = self.patch_merge(x).view(b, -1, new_h, new_w).permute(0, 2, 3, 1)
        # print("before patch_merge",x.shape)
        x = self.patch_merge(x)
        x = self.bn(x)
        # print("after patch_merge",x.shape)
        x = x.view(b, -1, new_h, new_w)
        x = x.permute(0, 2, 3, 1)
        # print("before linear",x.shape)

        # print("after linear",x.shape)
        return x

class PatchExpanding():
    def __init__(self, in_channels, out_channels, upscaling_factor):
        super().__init__()
        self.upscaling_factor = upscaling_factor
        self.patch_expand = nn.fold(kernel_size=downscaling_factor, stride=downscaling_factor, padding=0)
        self.linear = nn.Linear(in_channels * downscaling_factor ** 2, out_channels)

    def forward(self, x):
        b, c, h, w = x.shape
        new_h, new_w = h * self.upscaling_factor, w * self.upscaling_factor
        x = self.patch_merge(x).view(b, -1, new_h, new_w).permute(0, 2, 3, 1)
        x = self.linear(x)
        return x 

class StageModule(nn.Module):
    def __init__(self, in_channels, hidden_dimension, layers, downscaling_factor, num_heads, head_dim, window_size,
                 relative_pos_embedding):
        super().__init__()
        assert layers % 2 == 0, 'Stage layers need to be divisible by 2 for regular and shifted block.'

        self.patch_partition = PatchMerging(in_channels=in_channels, out_channels=hidden_dimension,
                                            downscaling_factor=downscaling_factor)

        self.layers = nn.ModuleList([])
        for _ in range(layers // 2):
            self.layers.append(nn.ModuleList([
                SwinBlock(dim=hidden_dimension, heads=num_heads, head_dim=head_dim, mlp_dim=hidden_dimension * 4,
                          shifted=False, window_size=window_size, relative_pos_embedding=relative_pos_embedding),
                SwinBlock(dim=hidden_dimension, heads=num_heads, head_dim=head_dim, mlp_dim=hidden_dimension * 4,
                          shifted=True, window_size=window_size, relative_pos_embedding=relative_pos_embedding),
            ]))

    def forward(self, x):
        # print("before patch_partition: ",x.shape)
        x = self.patch_partition(x)
        # print("after patch_partition: ",x.shape)
        for regular_block, shifted_block in self.layers:
            x = regular_block(x)
            x = shifted_block(x)
        return x.permute(0, 3, 1, 2)

def _get_padding(padding_type, kernel_size):
    assert padding_type in ['SAME', 'VALID']
    if padding_type == 'SAME':
        _list = [(k - 1) // 2 for k in kernel_size]
        return tuple(_list)
    return tuple(0 for _ in kernel_size) 

class SwinTransformer(nn.Module):
    def __init__(self, *, hidden_dim, layers, heads, channels=3, num_classes=1000, head_dim=32, window_size=16,
                 downscaling_factors=(2, 2, 2, 2, 2), relative_pos_embedding=True):
        super().__init__()
        
        self.stage0 = StageModule(in_channels=channels, hidden_dimension=hidden_dim, layers=layers[0],
                                  downscaling_factor=downscaling_factors[0], num_heads=heads[0], head_dim=head_dim,
                                  window_size=window_size, relative_pos_embedding=relative_pos_embedding)
        self.stage1 = StageModule(in_channels=hidden_dim, hidden_dimension=hidden_dim*2, layers=layers[1],
                                  downscaling_factor=downscaling_factors[1], num_heads=heads[1], head_dim=head_dim,
                                  window_size=window_size, relative_pos_embedding=relative_pos_embedding)
        self.stage2 = StageModule(in_channels=hidden_dim*2, hidden_dimension=hidden_dim * 4, layers=layers[2],
                                  downscaling_factor=downscaling_factors[2], num_heads=heads[2], head_dim=head_dim,
                                  window_size=window_size, relative_pos_embedding=relative_pos_embedding)
        self.stage3 = StageModule(in_channels=hidden_dim * 4, hidden_dimension=hidden_dim * 8, layers=layers[3],
                                  downscaling_factor=downscaling_factors[3], num_heads=heads[3], head_dim=head_dim,
                                  window_size=window_size, relative_pos_embedding=relative_pos_embedding)
        self.stage4 = StageModule(in_channels=hidden_dim * 8, hidden_dimension=hidden_dim * 16, layers=layers[4],
                                  downscaling_factor=downscaling_factors[4], num_heads=heads[4], head_dim=head_dim,
                                  window_size=window_size, relative_pos_embedding=relative_pos_embedding)

       

    def forward(self, img):
        h = img.size()[2]
        w = img.size()[3]
        x = img
        return x
    
class SwinTransformer_m(nn.Module):
    def __init__(self, *, hidden_dim, layers, heads, channels=3, num_classes=1000, head_dim=32, window_size=16,
                 downscaling_factors=(4, 2, 2, 2), relative_pos_embedding=True):
        super().__init__()
        
        self.stage0 = StageModule(in_channels=channels, hidden_dimension=hidden_dim*2, layers=layers[0],
                                  downscaling_factor=downscaling_factors[0], num_heads=heads[0], head_dim=head_dim,
                                  window_size=window_size, relative_pos_embedding=relative_pos_embedding)
        self.stage1 = StageModule(in_channels=hidden_dim*2, hidden_dimension=hidden_dim*4, layers=layers[1],
                                  downscaling_factor=downscaling_factors[1], num_heads=heads[1], head_dim=head_dim,
                                  window_size=window_size, relative_pos_embedding=relative_pos_embedding)
        self.stage2 = StageModule(in_channels=hidden_dim*4, hidden_dimension=hidden_dim * 8, layers=layers[2],
                                  downscaling_factor=downscaling_factors[2], num_heads=heads[2], head_dim=head_dim,
                                  window_size=window_size, relative_pos_embedding=relative_pos_embedding)
        self.stage3 = StageModule(in_channels=hidden_dim * 8, hidden_dimension=hidden_dim * 16, layers=layers[3],
                                  downscaling_factor=downscaling_factors[3], num_heads=heads[3], head_dim=head_dim,
                                  window_size=window_size, relative_pos_embedding=relative_pos_embedding)


       

    def forward(self, img):
        h = img.size()[2]
        w = img.size()[3]
        x = img
        return x

class SwinTransformer_s(nn.Module):
    def __init__(self, *, hidden_dim, layers, heads, channels=3, num_classes=1000, head_dim=32, window_size=16,
                 downscaling_factors=(2, 2, 2), relative_pos_embedding=True):
        super().__init__()
        
        self.stage0 = StageModule(in_channels=channels, hidden_dimension=hidden_dim, layers=layers[0],
                                  downscaling_factor=downscaling_factors[0], num_heads=heads[0], head_dim=head_dim,
                                  window_size=window_size, relative_pos_embedding=relative_pos_embedding)
        self.stage1 = StageModule(in_channels=hidden_dim, hidden_dimension=hidden_dim*2, layers=layers[1],
                                  downscaling_factor=downscaling_factors[1], num_heads=heads[1], head_dim=head_dim,
                                  window_size=window_size, relative_pos_embedding=relative_pos_embedding)
        self.stage2 = StageModule(in_channels=hidden_dim*2, hidden_dimension=hidden_dim * 4, layers=layers[2],
                                  downscaling_factor=downscaling_factors[2], num_heads=heads[2], head_dim=head_dim,
                                  window_size=window_size, relative_pos_embedding=relative_pos_embedding)

       

    def forward(self, img):
        h = img.size()[2]
        w = img.size()[3]
        x = img
        return x


def swin_s(hidden_dim=64, layers=(2, 2, 2, 8, 2), heads=(2, 4, 8, 16, 32), channels=3, num_classes=8,head_dim=32,window_size=16,downscaling_factors=(2, 2, 2, 2, 2),relative_pos_embedding=True):
    return SwinTransformer(hidden_dim=hidden_dim, layers=layers, heads=heads, channels=channels,num_classes=num_classes,head_dim=head_dim,window_size=window_size,downscaling_factors=downscaling_factors,relative_pos_embedding=relative_pos_embedding)


### network ###
class conv_block(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(conv_block, self).__init__()
        self.activation = nn.ReLU(inplace=True)
        self.conv1 = nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1, bias=True)
        self.bn1 = nn.BatchNorm2d(out_ch)


    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        output = self.activation(x)

        return output

class conv_block_nested(nn.Module):
    def __init__(self, in_ch, mid_ch, out_ch):
        super(conv_block_nested, self).__init__()
        self.activation = nn.ReLU(inplace=True)
        self.conv1 = nn.Conv2d(in_ch, mid_ch, kernel_size=3, padding=1, bias=True)
        self.bn1 = nn.BatchNorm2d(mid_ch)
        self.conv2 = nn.Conv2d(mid_ch, out_ch, kernel_size=3, padding=1, bias=True)
        self.bn2 = nn.BatchNorm2d(out_ch)

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.activation(x)

        x = self.conv2(x)
        x = self.bn2(x)
        output = self.activation(x)
        return output

class conv_block_nest(nn.Module):
    def __init__(self, in_ch,out_ch):
        super(conv_block_nest, self).__init__()
        self.activation = nn.ReLU(inplace=True)
        self.conv1 = nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1, bias=True)
        self.bn1 = nn.BatchNorm2d(out_ch)

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        output = self.activation(x)
        return output

class upsample_layer(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(upsample_layer, self).__init__()
        self.up = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.activation = nn.ReLU(inplace=True)
        self.conv1 = nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1, bias=True)
        self.bn1 = nn.BatchNorm2d(out_ch)

    def forward(self, x):
        x = self.up(x)
        x = self.conv1(x)
        x = self.bn1(x)
        output = self.activation(x)
        return output

class upsample_layer4(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(upsample_layer4, self).__init__()
        self.up = nn.Upsample(scale_factor=4, mode='bilinear', align_corners=True)
        self.activation = nn.ReLU(inplace=True)
        self.conv1 = nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1, bias=True)
        self.bn1 = nn.BatchNorm2d(out_ch)

    def forward(self, x):
        x = self.up(x)
        x = self.conv1(x)
        x = self.bn1(x)
        output = self.activation(x)
        return output

class upsample_layer8(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(upsample_layer8, self).__init__()
        self.up = nn.Upsample(scale_factor=8, mode='bilinear', align_corners=True)
        self.activation = nn.ReLU(inplace=True)
        self.conv1 = nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1, bias=True)
        self.bn1 = nn.BatchNorm2d(out_ch)

    def forward(self, x):
        x = self.up(x)
        x = self.conv1(x)
        x = self.bn1(x)
        output = self.activation(x)
        return output

class upsample_layer16(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(upsample_layer16, self).__init__()
        self.up = nn.Upsample(scale_factor=16, mode='bilinear', align_corners=True)
        self.activation = nn.ReLU(inplace=True)
        self.conv1 = nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1, bias=True)
        self.bn1 = nn.BatchNorm2d(out_ch)

    def forward(self, x):
        x = self.up(x)
        x = self.conv1(x)
        x = self.bn1(x)
        output = self.activation(x)
        return output    

class downsample_layer(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(downsample_layer, self).__init__()
        self.down = nn.MaxPool2d(kernel_size=2)
        self.activation = nn.ReLU(inplace=True)
        self.conv1 = nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1, bias=True)
        self.bn1 = nn.BatchNorm2d(out_ch)

    def forward(self, x):
        x = self.down(x)
        x = self.conv1(x)
        x = self.bn1(x)
        output = self.activation(x)
        return output

class downsample_layer4(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(downsample_layer4, self).__init__()
        self.down = nn.MaxPool2d(kernel_size=2)
        self.activation = nn.ReLU(inplace=True)
        self.conv1 = nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1, bias=True)
        self.bn1 = nn.BatchNorm2d(out_ch)

    def forward(self, x):
        x = self.down(x)
        x = self.down(x)
        x = self.conv1(x)
        x = self.bn1(x)
        output = self.activation(x)
        return output

class downsample_layer8(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(downsample_layer8, self).__init__()
        self.down = nn.MaxPool2d(kernel_size=2)
        self.activation = nn.ReLU(inplace=True)
        self.conv1 = nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1, bias=True)
        self.bn1 = nn.BatchNorm2d(out_ch)

    def forward(self, x):
        x = self.down(x)
        x = self.down(x)
        x = self.down(x)
        x = self.conv1(x)
        x = self.bn1(x)
        output = self.activation(x)
        return output

  
    

class SPAM(nn.Module):

    """ Position Attention Module """
    def __init__(self, channel):
        super(SPAM, self).__init__()
        self.conv = nn.Conv2d(channel, 1, kernel_size=1)
        self.act = nn.Sigmoid()
        self.gamma = nn.Parameter(torch.zeros(1))
    def forward(self, x):
        """
        Args:
            x ([torch.tensor]): size N*C*H*W
        Returns:
            [torch.tensor]: size N*C*H*W
        """
        _, c, _, _ = x.size()
        y = self.act(self.conv(x))
        y = y.repeat(1, c, 1, 1)
        out = x + self.gamma*x * y
        return out

class AFM1(nn.Module):


    def __init__(self):
        super(AFM1, self).__init__()
        self.conv = nn.Conv2d(256, 64, kernel_size=3, padding=1, bias=True)
        self.activation = nn.ReLU(inplace=True)
        self.bn = nn.BatchNorm2d(64)
        self.gamma1 = nn.Parameter(torch.zeros(1))
        self.gamma2 = nn.Parameter(torch.zeros(1))        
    def forward(self, x1,x2,x3,x4,x5):

        out1=torch.cat([x2,x3,x4,x5], dim=1)
        out1=self.conv(out1)
        out1 = self.bn(out1)
        out1 = self.activation(out1)
        out2=x2+x3+x4+x5
        out=x1+self.gamma1*out1+self.gamma2*out2

        return out

class AFM2(nn.Module):


    def __init__(self):
        super(AFM2, self).__init__()
        self.conv = nn.Conv2d(384, 128, kernel_size=3, padding=1, bias=True)
        self.activation = nn.ReLU(inplace=True)
        self.bn = nn.BatchNorm2d(128)
        self.gamma1 = nn.Parameter(torch.zeros(1))
        self.gamma2 = nn.Parameter(torch.zeros(1))        
    def forward(self, x1,x2,x3,x4):

        out1=torch.cat([x2,x3,x4], dim=1)
        out1=self.conv(out1)
        out1 = self.bn(out1)
        out1 = self.activation(out1)
        out2=x2+x3+x4
        out=x1+self.gamma1*out1+self.gamma2*out2

        return out

class AFM3(nn.Module):


    def __init__(self):
        super(AFM3, self).__init__()
        self.conv = nn.Conv2d(512, 256, kernel_size=3, padding=1, bias=True)
        self.activation = nn.ReLU(inplace=True)
        self.bn = nn.BatchNorm2d(256)
        self.gamma1 = nn.Parameter(torch.zeros(1))
        self.gamma2 = nn.Parameter(torch.zeros(1))
    def forward(self, x1,x2,x3):

        out1=torch.cat([x2,x3], dim=1)
        out1=self.conv(out1)
        out1 = self.bn(out1)
        out1 = self.activation(out1)
        out2=x2+x3
        out=x1+self.gamma1*out1+self.gamma2*out2

        return out

class AFM4(nn.Module):


    def __init__(self):
        super(AFM4, self).__init__()
        self.gamma = nn.Parameter(torch.zeros(1))
    def forward(self, x1,x2):
        
        out=x1+self.gamma*x2
        return out     


class AWMSA(nn.Module):

    def __init__(self):
        super(AWMSA, self).__init__()

        swin_raw_model = swin_s()
        swin_raw_model2 = swin_s()

        self.encoder_rgb_st0 = swin_raw_model.stage0
        self.encoder_rgb_st1 = swin_raw_model.stage1
        self.encoder_rgb_st2 = swin_raw_model.stage2
        self.encoder_rgb_st3 = swin_raw_model.stage3
        self.encoder_rgb_st4 = swin_raw_model.stage4

        self.encoder_a_st0 = swin_raw_model2.stage0
        self.encoder_a_st1 = swin_raw_model2.stage1
        self.encoder_a_st2 = swin_raw_model2.stage2
        self.encoder_a_st3 = swin_raw_model2.stage3
        self.encoder_a_st4 = swin_raw_model2.stage4




        self.pam0=SPAM(64)        
        self.pam1=SPAM(128)
        self.pam2=SPAM(256)
        self.pam3=SPAM(512)
        self.pam4=SPAM(1024)

        ###  composite  ###

        self.s1up1 = upsample_layer(128, 64)

        self.s2up1 = upsample_layer4(256, 64)
        self.s2up2 = upsample_layer(256, 128)


        self.s3up1 = upsample_layer8(512, 64)
        self.s3up2 = upsample_layer4(512, 128)
        self.s3up3 = upsample_layer(512, 256)

        self.s4up1 = upsample_layer16(1024, 64)
        self.s4up2 = upsample_layer8(1024, 128)
        self.s4up3 = upsample_layer4(1024, 256)
        self.s4up4 = upsample_layer(1024, 512)  

        self.afm1=AFM1()
        self.afm2=AFM2()
        self.afm3=AFM3()
        self.afm4=AFM4() 

        ###  decoder  ###

        self.conv1_0 = conv_block(128,64)
        self.conv2_0 = conv_block(256,128)
        self.conv3_0 = conv_block(512,256)
        self.conv4_0 = conv_block(1024,512)
        self.conv5_0 = conv_block(2048,1024)

        self.conv2_1 = conv_block_nested(128*3, 128, 128)
        self.conv3_1 = conv_block_nested(256*3, 256, 256)
        self.conv4_1 = conv_block_nested(512*3, 512, 512)

        self.up1 = upsample_layer(128, 64)
        self.up2 = upsample_layer(256, 128)
        self.up3 = upsample_layer(512, 256)
        self.up4 = upsample_layer(1024, 512)
        self.final = upsample_layer(64, 8)

        self.down1 = downsample_layer(64, 128)
        self.down2 = downsample_layer(128, 256)
        self.down3 = downsample_layer(256, 512)
        self.down4 = downsample_layer(512, 1024)



        ### layers without pretrained model need to be initialized ###
        self.need_initialization = [self.conv2_1, self.conv3_1, self.conv4_1, self.conv1_0,
                                    self.conv2_0, self.conv3_0, self.conv4_0, self.conv5_0, 
                                    self.up1, self.up2, self.up3,self.up4, self.final,
                                    self.down1, self.down2, self.down3, self.down4,
                                    self.s1up1,self.s2up1,self.s2up2,self.s3up1,self.s3up2,self.s3up3,
                                    self.s4up1,self.s4up2,self.s4up3,self.s4up4]





    def forward(self, input):

        rgb = input

        # encoder1
        rgbc = self.encoder_a_st0(rgb)

        rgbc = self.encoder_a_st1(rgbc)
        rgbcs1up1 = self.s1up1(rgbc)

        rgbc = self.encoder_a_st2(rgbc)
        rgbcs2up1 = self.s2up1(rgbc)
        rgbcs2up2 = self.s2up2(rgbc)

        rgbc = self.encoder_a_st3(rgbc)
        rgbcs3up1 = self.s3up1(rgbc)
        rgbcs3up2 = self.s3up2(rgbc)
        rgbcs3up3 = self.s3up3(rgbc)

        rgbc = self.encoder_a_st4(rgbc)
        rgbcs4up1 = self.s4up1(rgbc)
        rgbcs4up2 = self.s4up2(rgbc)
        rgbcs4up3 = self.s4up3(rgbc)
        rgbcs4up4 = self.s4up4(rgbc)

        # encoder2
        rgb = self.encoder_rgb_st0(rgb)
        x1_0 = rgb
        x1_0 = self.pam0(x1_0)
        #rgbc1 = rgb+rgbcs1up1+rgbcs2up1+rgbcs3up1+rgbcs4up1
        rgbc1 = self.afm1(rgb,rgbcs1up1,rgbcs2up1,rgbcs2up1,rgbcs4up1)


        
        rgb = self.encoder_rgb_st1(rgbc1)
        x2_0 = rgb
        x2_0 = self.pam1(x2_0)
        #print("st1:",x1_0.shape)
        #rgbc2 = rgb+rgbcs2up2+rgbcs3up2+rgbcs4up2
        rgbc2 = self.afm2(rgb,rgbcs2up2,rgbcs3up2,rgbcs4up2)

        rgb = self.encoder_rgb_st2(rgbc2)
        x3_0 = rgb
        x3_0 = self.pam2(x3_0)
        #print("st2:",x2_0.shape)
        #rgbc3 = rgb+rgbcs3up3+rgbcs4up3
        rgbc3 = self.afm3(rgb,rgbcs3up3,rgbcs4up3)

        rgb = self.encoder_rgb_st3(rgbc3)
        x4_0 = rgb
        x4_0 = self.pam3(x4_0)
        #print("st3:",x3_0.shape)
        #rgbc4 = rgb+rgbcs4up4
        rgbc4=self.afm4(rgb,rgbcs4up4)

        rgb = self.encoder_rgb_st4(rgbc4)
        x5_0 = rgb
        x5_0 = self.pam4(x5_0)
        #print("st4:",x4_0.shape)



        # decoder
        x20 = self.conv2_0(torch.cat([x2_0, self.down1(x1_0)], dim=1))
        x30 = self.conv3_0(torch.cat([x3_0, self.down2(x20)], dim=1))
        x40 = self.conv4_0(torch.cat([x4_0, self.down3(x30)], dim=1))
        x50 = self.conv5_0(torch.cat([x5_0, self.down4(x40)], dim=1))
        x41 = self.conv4_1(torch.cat([x4_0, x40, self.up4(x50)], dim=1))        
        x31 = self.conv3_1(torch.cat([x3_0, x30, self.up3(x41)], dim=1))
        x21 = self.conv2_1(torch.cat([x2_0, x20, self.up2(x31)], dim=1))
        x10 = self.conv1_0(torch.cat([x1_0, self.up1(x21)], dim=1))   
        out = self.final(x10)
        return out

    def init_weight(self):
        for ly in self.children():
            if isinstance(ly, nn.Conv2d):
                nn.init.kaiming_normal_(ly.weight, a=1)
                if not ly.bias is None: nn.init.constant_(ly.bias, 0)

    def get_params(self):
        wd_params, nowd_params = [], []
        for name, module in self.named_modules():
            if isinstance(module, (nn.Linear, nn.Conv2d)):
                wd_params.append(module.weight)
                if not module.bias is None:
                    nowd_params.append(module.bias)
            elif isinstance(module, BatchNorm2d):
                nowd_params += list(module.parameters())
        return wd_params, nowd_params  
    



