# camera-ready

import torch
import torch.nn as nn

import numpy as np

def add_weight_decay(net, l2_value, skip_list=()):
    # https://raberrytv.wordpress.com/2017/10/29/pytorch-weight-decay-made-easy/

    decay, no_decay = [], []
    for name, param in net.named_parameters():
        if not param.requires_grad:
            continue # frozen weights
        if len(param.shape) == 1 or name.endswith(".bias") or name in skip_list:
            no_decay.append(param)
        else:
            decay.append(param)

    return [{'params': no_decay, 'weight_decay': 0.0}, {'params': decay, 'weight_decay': l2_value}]

# function for colorizing a label image:
def label_img_to_color(img):
    label_to_color = {
        # 0: [128, 64,128],
        # 1: [244, 35,232],
        # 2: [ 70, 70, 70],
        # 3: [102,102,156],
        # 4: [190,153,153],
        # 5: [153,153,153],
        # 6: [250,170, 30],
        # 7: [220,220,  0],
        0: [0, 0, 0],
        1: [0, 0, 128],
        2: [128, 64, 128],
        3: [192, 0, 192],
        4: [0, 128, 0],
        5: [0, 128, 128],
        6: [0, 64, 64],
        7: [128, 0, 64],
        8: [107,142, 35],
        9: [152,251,152],
        10: [ 70,130,180],
        11: [220, 20, 60],
        12: [255,  0,  0],
        13: [  0,  0,142],
        14: [  0,  0, 70],
        15: [  0, 60,100],
        16: [  0, 80,100],
        17: [  0,  0,230],
        18: [119, 11, 32],
        19: [81,  0, 81]
        }

    img_height, img_width = img.shape
    # print(img.shape)
    # img_height, img_width = img.shape[1],img.shape[2]

    img_color = np.zeros((img_height, img_width, 3))
    for row in range(img_height):
        for col in range(img_width):
            label = img[row, col]

            img_color[row, col] = np.array(label_to_color[label])

    return img_color
