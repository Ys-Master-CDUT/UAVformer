# camera-ready

from datasetUAV import DatasetSeq, DatasetTest# (this needs to be imported before torch, because cv2 needs to be imported before torch for some reason)
from utilsUAV import label_img_to_color

from AWMSA import AWMSA
import torch
import torch.utils.data
import torch.nn as nn
from torch.autograd import Variable
import torch.optim as optim
import torch.nn.functional as F

import numpy as np
import pickle
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import cv2
import os
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "0,1,2,3"

if __name__ =="__main__":

    batch_size = 4


    network = AWMSA()  
    network.cuda()
    #device_ids = [i for i in range(torch.cuda.device_count())]
    #if torch.cuda.device_count() > 1:
        #print("\n\nLet's use", torch.cuda.device_count(), "GPUs!\n\n")
    #if len(device_ids)>1:
        #network = nn.DataParallel(network, device_ids = device_ids)
        #network = network.cuda(device=device_ids[0])  # 模型放在主设备
    network.load_state_dict(torch.load("trainning_log/model_epoch_360.pth"))

    for sequence in ["0"]:
        print (sequence)

        #val_dataset = DatasetSeq(uavid_data_path="datasetUAV",
                                 #uavid_meta_path="datasetUAV",
                                 #sequence=sequence)
        val_dataset = DatasetTest(uavid_data_path="datasetUAV",
                                 uavid_meta_path="datasetUAV",
                                 sequence=sequence)
        num_val_batches = int(len(val_dataset)/batch_size)
        print ("num_val_batches:", num_val_batches)

        val_loader = torch.utils.data.DataLoader(dataset=val_dataset,
                                                batch_size=batch_size, shuffle=False,
                                                num_workers=8)

        network.eval() # (set in evaluation mode, this affects BatchNorm and dropout)
        unsorted_img_ids = []
        for step, (imgs, img_ids) in enumerate(val_loader):
            with torch.no_grad(): # (corresponds to setting volatile=True in all variables, this is done during inference to reduce memory consumption)
                imgs = Variable(imgs).cuda() # (shape: (batch_size, 3, img_h, img_w))

                outputs = network(imgs) # (shape: (batch_size, num_classes, img_h, img_w))

                ####################################################################
                # save data for visualization:
                ####################################################################
                outputs = outputs.data.cpu().numpy() # (shape: (batch_size, num_classes, img_h, img_w))
                pred_label_imgs = np.argmax(outputs, axis=1) # (shape: (batch_size, img_h, img_w))
                pred_label_imgs = pred_label_imgs.astype(np.uint8)

                for i in range(pred_label_imgs.shape[0]):
                    pred_label_img = pred_label_imgs[i] # (shape: (img_h, img_w))
                    img_id = img_ids[i]
                    img = imgs[i] # (shape: (3, img_h, img_w))

                    img = img.data.cpu().numpy()
                    img = np.transpose(img, (1, 2, 0)) # (shape: (img_h, img_w, 3))
                    img = img*np.array([0.229, 0.224, 0.225])
                    img = img + np.array([0.485, 0.456, 0.406])
                    img = img*255.0
                    img = img.astype(np.uint8)

                    pred_label_img_color  = label_img_to_color(pred_label_img)
                    
                    overlayed_img = 0.35*img + 0.65*pred_label_img_color
                    overlayed_img = overlayed_img.astype(np.uint8)

                    img_h = overlayed_img.shape[0]
                    img_w = overlayed_img.shape[1]

                    #cv2.imwrite("result" + "/" + img_id + ".png", img)
                    cv2.imwrite("datasetUAV" + "/" +"UAVidresult" + "/" + img_id + "_pred.png", pred_label_img_color)
                    cv2.imwrite("datasetUAV" + "/"+"UAVidresult" + "/" + img_id + "_overlayed.png", overlayed_img)

                    unsorted_img_ids.append(img_id)


